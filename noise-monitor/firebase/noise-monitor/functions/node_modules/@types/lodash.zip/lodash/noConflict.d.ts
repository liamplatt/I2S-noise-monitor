import { noConflict } from "./index";
export = noConflict;
