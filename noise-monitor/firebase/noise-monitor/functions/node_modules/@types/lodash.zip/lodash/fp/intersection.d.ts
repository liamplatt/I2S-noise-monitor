import { intersection } from "../fp";
export = intersection;
