import { F } from "../fp";
export = F;
