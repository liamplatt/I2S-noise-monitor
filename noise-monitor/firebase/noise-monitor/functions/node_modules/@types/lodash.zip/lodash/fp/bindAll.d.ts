import { bindAll } from "../fp";
export = bindAll;
