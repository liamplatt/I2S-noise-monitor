import { difference } from "./index";
export = difference;
