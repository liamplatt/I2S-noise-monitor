import { toNumber } from "./index";
export = toNumber;
