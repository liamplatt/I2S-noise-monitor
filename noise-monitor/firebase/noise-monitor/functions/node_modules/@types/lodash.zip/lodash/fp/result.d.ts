import { result } from "../fp";
export = result;
