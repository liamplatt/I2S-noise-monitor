import { once } from "../fp";
export = once;
