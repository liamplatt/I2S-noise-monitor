import { rangeStep } from "../fp";
export = rangeStep;
