import { nth } from "./index";
export = nth;
