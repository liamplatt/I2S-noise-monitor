import { zipObjectDeep } from "./index";
export = zipObjectDeep;
