import { curryRight } from "./index";
export = curryRight;
