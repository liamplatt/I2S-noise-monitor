import { multiply } from './index';
export = multiply;
