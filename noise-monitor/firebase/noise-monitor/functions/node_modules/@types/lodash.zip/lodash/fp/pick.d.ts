import { pick } from "../fp";
export = pick;
