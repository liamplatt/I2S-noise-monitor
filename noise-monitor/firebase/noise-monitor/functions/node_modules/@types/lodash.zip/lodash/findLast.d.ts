import { findLast } from "./index";
export = findLast;
