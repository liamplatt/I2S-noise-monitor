import { remove } from "./index";
export = remove;
