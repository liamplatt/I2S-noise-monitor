import { toUpper } from "./index";
export = toUpper;
