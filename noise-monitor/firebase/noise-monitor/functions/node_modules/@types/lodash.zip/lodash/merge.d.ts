import { merge } from "./index";
export = merge;
