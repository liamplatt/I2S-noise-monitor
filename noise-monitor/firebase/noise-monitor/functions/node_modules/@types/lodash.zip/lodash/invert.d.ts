import { invert } from "./index";
export = invert;
