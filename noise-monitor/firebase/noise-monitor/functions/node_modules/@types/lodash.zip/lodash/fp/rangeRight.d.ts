import { rangeRight } from "../fp";
export = rangeRight;
