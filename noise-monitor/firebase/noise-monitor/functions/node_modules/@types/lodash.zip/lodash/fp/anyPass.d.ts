import { anyPass } from "../fp";
export = anyPass;
