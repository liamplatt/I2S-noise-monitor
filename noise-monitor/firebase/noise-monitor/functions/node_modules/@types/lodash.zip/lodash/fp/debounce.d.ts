import { debounce } from "../fp";
export = debounce;
