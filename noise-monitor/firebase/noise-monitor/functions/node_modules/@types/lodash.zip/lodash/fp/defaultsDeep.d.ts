import { defaultsDeep } from "../fp";
export = defaultsDeep;
