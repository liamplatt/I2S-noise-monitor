import { find } from "../fp";
export = find;
