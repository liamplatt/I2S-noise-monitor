import { flatMap } from "./index";
export = flatMap;
