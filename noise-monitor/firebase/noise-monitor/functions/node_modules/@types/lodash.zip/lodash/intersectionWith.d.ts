import { intersectionWith } from "./index";
export = intersectionWith;
