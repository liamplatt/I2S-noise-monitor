import { indexOf } from "../fp";
export = indexOf;
