import { pull } from "./index";
export = pull;
