import { reduceRight } from "./index";
export = reduceRight;
